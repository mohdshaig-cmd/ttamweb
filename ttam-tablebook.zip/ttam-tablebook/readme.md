# TTAM CourtFlow Production Scaffold

This folder contains a production-ready backend structure for moving the current TTAM CourtFlow HTML demo to **Supabase + Netlify**.

## What is included
- `sql/001_schema.sql` — core tables, triggers, helper functions, invoice / booking references
- `sql/002_policies.sql` — row-level security policies
- `sql/003_seed.sql` — starter records matching the demo content
- `netlify.toml` — Netlify deployment config
- `netlify/functions/send-booking-email.mjs` — email automation function using Resend
- `js/config.example.js` — frontend config template
- `js/supabase-client.js` — Supabase client bootstrap
- `js/supabase-data-layer.js` — production data access functions to swap in for localStorage
- `migration-notes.md` — exact places in the current HTML file to replace

## Deploy flow
1. Create a Supabase project.
2. Run the SQL files in order:
   - `001_schema.sql`
   - `002_policies.sql`
   - `003_seed.sql`
3. Create a Netlify site from your Git repo.
4. Add environment variables in Netlify:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
   - `RESEND_API_KEY`
   - `EMAIL_FROM`
5. Copy `js/config.example.js` to `js/config.js` and fill in the values.
6. Replace the demo `loadData`, `saveData`, auth handlers, and booking CRUD calls using `migration-notes.md`.

## Important
This scaffold gives you the **database shape, security, storage rules, serverless email layer, and frontend integration functions**.
It does **not** magically rewrite every localStorage line in the current HTML on its own.
Use the mapping file to wire the existing UI to the new backend.


## Branded email templates
The Netlify function `netlify/functions/send-booking-email.mjs` now supports template-driven branded emails.

Supported templates:
- `booking-submitted`
- `receipt-submitted`
- `admin-receipt-alert`
- `booking-approved`
- `booking-rejected`

Example payload:
```json
{
  "to": "member@example.com",
  "template": "booking-approved",
  "data": {
    "ref": "BK-1021",
    "courtName": "Table 2",
    "bookingDate": "2026-05-12",
    "startTime": "18:00",
    "durationHours": 2,
    "amount": 160,
    "paymentMethod": "Bank transfer",
    "invoiceNo": "INV-2026-0004",
    "comments": "Payment verified and booking confirmed."
  }
}
```
