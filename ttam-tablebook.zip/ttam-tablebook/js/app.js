const state = {
  user: null,
  page: 'dashboard',
  authTab: 'signin',
  bookingDraft: {
    booking_date: new Date().toISOString().split('T')[0],
    start_time: '18:00',
    duration_hours: 1,
    court_id: '',
    payment_method: 'Bank transfer',
    notes: ''
  },
  association: { contact: null, committee: [], tournaments: [] }
};

function todayISO() {
  return new Date().toISOString().split('T')[0];
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  }[c]));
}

function fmtMoney(n) {
  return new Intl.NumberFormat('en-MV', {
    style: 'currency',
    currency: 'MVR',
    minimumFractionDigits: 2
  }).format(Number(n || 0));
}

function fmtDate(s) {
  if (!s) return '';
  const d = new Date(s);
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}

function fmtTime(s) {
  return String(s || '').slice(0, 5);
}

function addHours(time, hours) {
  const [h, m] = String(time).slice(0, 5).split(':').map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  d.setHours(d.getHours() + Number(hours || 0));
  return d.toTimeString().slice(0, 5);
}

function statusClass(prefix, v) {
  return `badge ${prefix}-${String(v || '').toLowerCase().replace(/\s+/g, '-')}`;
}

function toast(msg, kind = 'info') {
  const stack = document.getElementById('toastStack');
  if (!stack) {
    console.warn('toastStack missing:', msg);
    return;
  }
  const el = document.createElement('div');
  el.className = 'toast toast-' + kind;
  el.textContent = msg;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 4500);
}

function setHtml(id, html) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = html;
}

function assertConfig() {
  if (!window.APP_CONFIG?.SUPABASE_URL || !window.APP_CONFIG?.SUPABASE_ANON_KEY) {
    const root = document.getElementById('root');
    if (root) {
      root.innerHTML = `
        <div class="center">
          <div class="auth-card">
            <div class="brand" style="margin-bottom:20px;">
              <div class="brand-badge">🏓</div>
              <div><h1>TTAM CourtFlow</h1><p>Supabase setup needed</p></div>
            </div>
            <div class="notice warn">
              Fill <span class="mono">js/config.js</span> with your Supabase URL and anon key, then refresh.
            </div>
            <div class="demo-login-chip">
              This package is already wired to the live schema. It just needs keys and deployment.
            </div>
          </div>
        </div>`;
    }
    return false;
  }
  return true;
}

async function loadAssociation() {
  const [contact, committee, tournaments] = await Promise.all([
    DataLayer.getContactSettings(),
    DataLayer.listExecutiveCommittee(),
    DataLayer.listTournaments()
  ]);
  state.association = { contact, committee, tournaments };
}

async function boot() {
  if (!assertConfig()) return;
  try {
    const session = await DataLayer.getSession();
    await loadAssociation();

    if (session) {
      state.user = await DataLayer.getCurrentUserProfile();
      render();
      initRealtime();
    } else {
      state.user = null;
      render();
    }
  } catch (err) {
    console.error(err);
    setHtml(
      'root',
      `<div class="center"><div class="auth-card"><div class="notice error">${esc(err.message || 'App failed to start')}</div></div></div>`
    );
  }
}

let bookingSubscription = null;
function initRealtime() {
  if (bookingSubscription || !DataLayer.subscribeToBookings) return;

  bookingSubscription = DataLayer.subscribeToBookings(async () => {
    try {
      if (
        state.page === 'book' ||
        state.page === 'my-bookings' ||
        state.page === 'admin-bookings' ||
        state.page === 'admin-payments' ||
        state.page === 'dashboard'
      ) {
        render();
        await hydratePage();
      }
    } catch (e) {
      console.error(e);
    }
  });
}

function render() {
  const root = document.getElementById('root');
  if (!root) return;

  if (!state.user) {
    root.innerHTML = renderAuth();
    bindAuth();
    return;
  }

  const admin = state.user.role === 'admin';
  if (!admin && state.page.startsWith('admin-')) {
    state.page = 'dashboard';
  }

  root.innerHTML = `
    <div class="app-shell">
      ${renderSidebar()}
      <main class="main">${renderPage()}</main>
    </div>`;

  bindSidebar();
  bindPage();
}

function renderAuth() {
  return `
  <div class="center">
    <div class="auth-card">
      <div class="brand" style="margin-bottom:20px;">
        <div class="brand-badge">🏓</div>
        <div><h1>TTAM CourtFlow</h1><p>Supabase + Netlify production edition</p></div>
      </div>
      <div class="auth-tabs">
        <button class="${state.authTab === 'signin' ? 'active' : ''}" data-auth-tab="signin">Sign in</button>
        <button class="${state.authTab === 'signup' ? 'active' : ''}" data-auth-tab="signup">Create account</button>
      </div>
      ${state.authTab === 'signin' ? `
        <form id="signinForm" class="stack">
          <div class="field"><label>Email</label><input class="input" type="email" id="signinEmail" required></div>
          <div class="field"><label>Password</label><input class="input" type="password" id="signinPassword" required></div>
          <button class="btn btn-primary" style="width:100%;" type="submit">Sign in</button>
        </form>
      ` : `
        <form id="signupForm" class="stack">
          <div class="field"><label>Full name</label><input class="input" id="signupName" required></div>
          <div class="field"><label>Email</label><input class="input" type="email" id="signupEmail" required></div>
          <div class="field"><label>Phone</label><input class="input" id="signupPhone"></div>
          <div class="field"><label>Password</label><input class="input" type="password" id="signupPassword" minlength="6" required></div>
          <button class="btn btn-primary" style="width:100%;" type="submit">Create account</button>
        </form>
      `}
      <div class="demo-login-chip">
        <strong>Ready for real Supabase auth.</strong><br>
        After sign-up, the SQL trigger will create the profile automatically.
      </div>
    </div>
  </div>`;
}

function bindAuth() {
  document.querySelectorAll('[data-auth-tab]').forEach(btn => {
    btn.onclick = () => {
      state.authTab = btn.dataset.authTab;
      render();
    };
  });

  const signin = document.getElementById('signinForm');
  if (signin) {
    signin.onsubmit = async (e) => {
      e.preventDefault();
      try {
        await DataLayer.signIn(
          document.getElementById('signinEmail').value.trim(),
          document.getElementById('signinPassword').value
        );
        state.user = await DataLayer.getCurrentUserProfile();
        await loadAssociation();
        render();
        initRealtime();
        toast('Signed in.', 'success');
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  }

  const signup = document.getElementById('signupForm');
  if (signup) {
    signup.onsubmit = async (e) => {
      e.preventDefault();
      try {
        await DataLayer.signUp({
          full_name: document.getElementById('signupName').value.trim(),
          email: document.getElementById('signupEmail').value.trim(),
          phone: document.getElementById('signupPhone').value.trim(),
          password: document.getElementById('signupPassword').value
        });
        state.authTab = 'signin';
        render();
        toast('Account created. Check your inbox if email confirmation is enabled.', 'success');
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  }
}

function renderSidebar() {
  const unread = 0;
  const memberNav = [
    ['dashboard', '📊', 'Dashboard'],
    ['book', '📅', 'Book a Table'],
    ['my-bookings', '📋', 'My Bookings'],
    ['notifications', '🔔', 'Notifications'],
    ['association', '🏛️', 'Association'],
    ['contact', '✉️', 'Contact Us']
  ];
  const adminNav = [
    ['admin-bookings', '📚', 'All Bookings'],
    ['admin-payments', '💳', 'Payments'],
    ['admin-tables', '🏓', 'Courts'],
    ['admin-members', '👥', 'Members'],
    ['admin-messages', '📨', 'Messages'],
    ['admin-association', '🛠️', 'Association CMS']
  ];

  const navItem = ([key, icon, label]) => `
    <div class="nav-item ${state.page === key ? 'active' : ''}" data-nav="${key}">
      <div class="icon">${icon}</div>
      <span>${label}</span>
      ${key === 'notifications' && unread ? `<span class="nav-badge">${unread}</span>` : ''}
    </div>`;

  return `
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-badge">🏓</div>
        <div>
          <h1>TTAM CourtFlow</h1>
          <p><span class="live-dot"></span>${esc(state.user.full_name)}</p>
        </div>
      </div>
      <div class="nav-section">Member</div>
      ${memberNav.map(navItem).join('')}
      ${state.user.role === 'admin' ? `<div class="nav-section">Admin</div>${adminNav.map(navItem).join('')}` : ''}
      <div style="margin-top:18px;padding:0 6px;">
        <button class="btn" style="width:100%;" id="logoutBtn">Sign out</button>
      </div>
    </aside>`;
}

function bindSidebar() {
  document.querySelectorAll('[data-nav]').forEach(el => {
    el.onclick = async () => {
      state.page = el.dataset.nav;
      await renderPageAsync();
    };
  });

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.onclick = async () => {
      await DataLayer.signOut();
      state.user = null;
      state.page = 'dashboard';
      render();
    };
  }
}

async function renderPageAsync() {
  render();
  await hydratePage();
}

function renderPage() {
  switch (state.page) {
    case 'dashboard':
      return renderDashboardShell();
    case 'book':
      return renderBookShell();
    case 'my-bookings':
      return renderMyBookingsShell();
    case 'notifications':
      return renderNotificationsShell();
    case 'association':
      return renderAssociation();
    case 'contact':
      return renderContact();
    case 'admin-bookings':
      return renderAdminBookingsShell();
    case 'admin-payments':
      return renderAdminPaymentsShell();
    case 'admin-tables':
      return renderAdminTablesShell();
    case 'admin-members':
      return renderAdminMembersShell();
    case 'admin-messages':
      return renderAdminMessagesShell();
    case 'admin-association':
      return renderAdminAssociation();
    default:
      return renderDashboardShell();
  }
}

function bindPage() {
  hydratePage();
}

async function hydratePage() {
  try {
    switch (state.page) {
      case 'dashboard':
        return await hydrateDashboard();
      case 'book':
        return await hydrateBook();
      case 'my-bookings':
        return await hydrateMyBookings();
      case 'notifications':
        return await hydrateNotifications();
      case 'contact':
        return bindContact();
      case 'admin-bookings':
        return await hydrateAdminBookings();
      case 'admin-payments':
        return await hydrateAdminPayments();
      case 'admin-tables':
        return await hydrateAdminTables();
      case 'admin-members':
        return await hydrateAdminMembers();
      case 'admin-messages':
        return await hydrateAdminMessages();
      case 'admin-association':
        return bindAdminAssociation();
      default:
        return;
    }
  } catch (err) {
    console.error(err);
    toast(err.message || 'Something broke.', 'error');
  }
}

function renderTopbar(title, subtitle, extra = '') {
  return `<div class="topbar"><div class="headline"><h2>${title}</h2><p>${subtitle}</p></div><div class="top-actions">${extra}</div></div>`;
}

function renderDashboardShell() {
  return `${renderTopbar('Welcome, ' + esc(state.user.full_name.split(' ')[0]), 'Live data from Supabase.')}<div id="dashboardArea"><div class="card"><div class="empty">Loading dashboard…</div></div></div>`;
}

async function hydrateDashboard() {
  const myBookings = await DataLayer.listMyBookings();
  const upcoming = myBookings.filter(b => b.booking_date >= todayISO() && b.status !== 'Cancelled').slice(0, 5);

  let adminMetrics = '';
  if (state.user.role === 'admin') {
    const all = await DataLayer.listAllBookings();
    const today = todayISO();
    adminMetrics = `
      <div class="grid cols-3" style="margin-bottom:14px;">
        <div class="metric"><div class="label">Bookings today</div><div class="value">${all.filter(b => b.booking_date === today && b.status !== 'Cancelled').length}</div></div>
        <div class="metric"><div class="label">Pending approvals</div><div class="value">${all.filter(b => b.status === 'Pending').length}</div></div>
        <div class="metric"><div class="label">Pending verification</div><div class="value">${all.filter(b => b.payment_status === 'Pending Verification').length}</div></div>
      </div>`;
  }

  setHtml('dashboardArea', `
    ${adminMetrics}
    <div class="card">
      <h3>My upcoming bookings</h3>
      <div class="card-sub">Straight from the bookings table.</div>
      ${upcoming.length ? `
        <div class="table-wrap">
          <table class="tt">
            <thead>
              <tr><th>Ref</th><th>Court</th><th>Date</th><th>Time</th><th>Status</th><th>Payment</th></tr>
            </thead>
            <tbody>
              ${upcoming.map(b => `
                <tr>
                  <td>${esc(b.ref)}</td>
                  <td>${esc(b.courts?.name || '—')}</td>
                  <td>${fmtDate(b.booking_date)}</td>
                  <td>${fmtTime(b.start_time)} · ${b.duration_hours}h</td>
                  <td><span class="${statusClass('status', b.status)}">${esc(b.status)}</span></td>
                  <td><span class="${statusClass('pay', b.payment_status)}">${esc(b.payment_status)}</span></td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>` : `<div class="empty">No upcoming bookings yet.</div>`}
    </div>`);
}

function renderBookShell() {
  return `${renderTopbar('Book a table', 'Bookings are limited by table availability and operating hours.')}<div id="bookArea"><div class="card"><div class="empty">Loading courts…</div></div></div>`;
}

async function hydrateBook() {
  const courts = await DataLayer.listCourts();
  const bookings = await DataLayer.listAllBookings();
  const draft = state.bookingDraft;
  const conflicts = new Set();
  const endTime = addHours(draft.start_time, draft.duration_hours);

  bookings
    .filter(b => b.booking_date === draft.booking_date && ['Pending', 'Confirmed'].includes(b.status))
    .forEach(b => {
      const bEnd = addHours(b.start_time, b.duration_hours);
      if (draft.start_time < bEnd && b.start_time < endTime) {
        conflicts.add(b.court_id);
      }
    });

  const selected = courts.find(c => c.id === draft.court_id);
  const total = selected ? Number(selected.rate) * Number(draft.duration_hours) : 0;

  setHtml('bookArea', `
    <form class="card" id="bookForm">
      <div class="grid cols-3">
        <div class="field"><label>Date</label><input class="input" type="date" id="bDate" min="${todayISO()}" value="${esc(draft.booking_date)}"></div>
        <div class="field"><label>Start time</label><input class="input" type="time" id="bTime" value="${esc(draft.start_time)}"></div>
        <div class="field"><label>Duration</label><select class="select" id="bDur">${[1, 2, 3, 4].map(h => `<option value="${h}" ${Number(draft.duration_hours) === h ? 'selected' : ''}>${h} hour${h > 1 ? 's' : ''}</option>`).join('')}</select></div>
      </div>
      <div style="margin-top:14px;">
        <div class="field" style="margin-bottom:8px;"><label>Pick a court</label></div>
        <div class="slot-grid">
          ${courts.map(c => {
            const blocked = c.status !== 'Active';
            const busy = conflicts.has(c.id);

            const openTime = fmtTime(c.open_time || '08:00');
            const closeTime = fmtTime(c.close_time || '22:00');
            const draftEnd = addHours(draft.start_time, draft.duration_hours);

            const outsideHours =
              draft.start_time < openTime ||
              draftEnd > closeTime;

            const disabled = blocked || busy || outsideHours;

            return `
              <div class="slot-card ${draft.court_id === c.id ? 'selected' : ''} ${disabled ? 'busy' : ''}" data-court-id="${c.id}" ${disabled ? 'data-disabled="1"' : ''}>
                <div class="name">${esc(c.name)}</div>
                <div class="surface">${esc(c.surface || '')}</div>
                <div class="rate">${fmtMoney(c.rate)} / hour</div>
                <div class="muted" style="font-size:11px;margin-top:4px;">Open: ${esc(openTime)} to ${esc(closeTime)}</div>
                <div class="avail" style="color:${blocked ? 'var(--danger)' : busy ? 'var(--warning)' : outsideHours ? 'var(--warning)' : 'var(--success)'}">
                  ${blocked
                    ? '● ' + esc(c.status)
                    : busy
                      ? '● Busy in this slot'
                      : outsideHours
                        ? '● Outside operating hours'
                        : '● Available'}
                </div>
              </div>`;
          }).join('')}
        </div>
      </div>
      <div class="grid cols-2" style="margin-top:14px;">
        <div class="field"><label>Payment method</label><select class="select" id="bPay">${['Bank transfer', 'Member account', 'Cash on arrival'].map(p => `<option ${draft.payment_method === p ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
        <div class="field"><label>Total</label><input class="input" value="${fmtMoney(total)}" readonly></div>
      </div>
      <div class="field"><label>Notes</label><textarea class="textarea" id="bNotes">${esc(draft.notes)}</textarea></div>
      ${state.association.contact?.bank_account ? `<div class="notice info">Transfer to <strong>${esc(state.association.contact.bank_account)}</strong> and upload your receipt in My Bookings.</div>` : ''}
      <div class="row"><button class="btn btn-primary" type="submit" ${!draft.court_id ? 'disabled' : ''}>Submit booking</button></div>
    </form>`);

  const bDate = document.getElementById('bDate');
  const bTime = document.getElementById('bTime');
  const bDur = document.getElementById('bDur');
  const bPay = document.getElementById('bPay');
  const bNotes = document.getElementById('bNotes');
  const bookForm = document.getElementById('bookForm');

  if (bDate) bDate.onchange = () => {
    state.bookingDraft.booking_date = bDate.value;
    state.bookingDraft.court_id = '';
    renderPageAsync();
  };

  if (bTime) bTime.onchange = () => {
    state.bookingDraft.start_time = bTime.value;
    state.bookingDraft.court_id = '';
    renderPageAsync();
  };

  if (bDur) bDur.onchange = () => {
    state.bookingDraft.duration_hours = Number(bDur.value);
    state.bookingDraft.court_id = '';
    renderPageAsync();
  };

  if (bPay) bPay.onchange = () => {
    state.bookingDraft.payment_method = bPay.value;
  };

  if (bNotes) bNotes.oninput = () => {
    state.bookingDraft.notes = bNotes.value;
  };

  document.querySelectorAll('[data-court-id]').forEach(el => {
    el.onclick = () => {
      if (el.dataset.disabled) return;
      state.bookingDraft.court_id = el.dataset.courtId;
      renderPageAsync();
    };
  });

  if (bookForm) {
    bookForm.onsubmit = async (e) => {
      e.preventDefault();
      try {
        const selectedCourt = courts.find(c => c.id === state.bookingDraft.court_id);
        if (selectedCourt) {
          const openTime = fmtTime(selectedCourt.open_time || '08:00');
          const closeTime = fmtTime(selectedCourt.close_time || '22:00');
          const draftEnd = addHours(state.bookingDraft.start_time, state.bookingDraft.duration_hours);

          if (state.bookingDraft.start_time < openTime || draftEnd > closeTime) {
            return toast(`This court is only available from ${openTime} to ${closeTime}.`, 'error');
          }
        }

        const created = await DataLayer.createBooking(state.bookingDraft);
        toast(`Booking ${created.ref} submitted.`, 'success');

        if (state.user.email) {
          try {
            await DataLayer.sendEmailAutomation({
              to: state.user.email,
              template: 'booking-submitted',
              data: {
                ref: created.ref,
                courtName: created.courts?.name,
                bookingDate: created.booking_date,
                startTime: created.start_time,
                durationHours: created.duration_hours,
                amount: created.amount,
                paymentMethod: created.payment_method
              }
            });
          } catch (_) {}
        }

        state.page = 'my-bookings';
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  }
}

function renderMyBookingsShell() {
  return `${renderTopbar('My bookings', 'Receipts, invoices, and cancellations live here.')}<div id="myBookingsArea"><div class="card"><div class="empty">Loading bookings…</div></div></div>`;
}

async function hydrateMyBookings() {
  const rows = await DataLayer.listMyBookings();

  setHtml('myBookingsArea', `
    <div class="card">
      ${rows.length ? `
        <div class="table-wrap">
          <table class="tt">
            <thead>
              <tr><th>Ref</th><th>Court</th><th>Date</th><th>Time</th><th>Amount</th><th>Status</th><th>Payment</th><th>Actions</th></tr>
            </thead>
            <tbody>
              ${rows.map(b => `
                <tr>
                  <td>${esc(b.ref)}</td>
                  <td>${esc(b.courts?.name || '—')}</td>
                  <td>${fmtDate(b.booking_date)}</td>
                  <td>${fmtTime(b.start_time)} · ${b.duration_hours}h</td>
                  <td>${fmtMoney(b.amount)}</td>
                  <td><span class="${statusClass('status', b.status)}">${esc(b.status)}</span></td>
                  <td>
                    <span class="${statusClass('pay', b.payment_status)}">${esc(b.payment_status)}</span>
                    ${b.invoice_no ? `<div class="muted" style="font-size:10px;">${esc(b.invoice_no)}</div>` : ''}
                  </td>
                  <td>
                    <div class="row" style="gap:5px;">
                      ${(b.payment_method === 'Bank transfer' && b.status !== 'Cancelled' && b.payment_status !== 'Paid') ? `<button class="btn btn-sm" data-upload="${b.id}">Receipt</button>` : ''}
                      ${(b.status === 'Pending' || b.status === 'Confirmed') && b.booking_date >= todayISO() ? `<button class="btn btn-sm btn-danger" data-cancel-booking="${b.id}">Cancel</button>` : ''}
                      ${b.invoice_no ? `<button class="btn btn-sm btn-primary" data-print-invoice="${b.id}">Invoice</button>` : ''}
                    </div>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>` : `<div class="empty">No bookings yet.</div>`}
    </div>`);

  document.querySelectorAll('[data-upload]').forEach(btn => {
    btn.onclick = () => openReceiptModal(btn.dataset.upload);
  });

  document.querySelectorAll('[data-cancel-booking]').forEach(btn => {
    btn.onclick = async () => {
      try {
        await DataLayer.cancelBooking(btn.dataset.cancelBooking);
        toast('Booking cancelled.', 'success');
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });

  document.querySelectorAll('[data-print-invoice]').forEach(btn => {
    btn.onclick = () => openInvoicePrint(rows.find(r => r.id === btn.dataset.printInvoice));
  });
}

function openReceiptModal(bookingId) {
  const html = `
    <div class="stack">
      <div class="field"><label>Receipt file</label><input class="input" type="file" id="receiptFile" accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf"></div>
      <div class="row"><button class="btn btn-primary" id="saveReceiptBtn">Upload receipt</button></div>
    </div>`;

  openModal('Upload receipt', html, (root, close) => {
    const saveBtn = root.querySelector('#saveReceiptBtn');
    if (!saveBtn) return;

    saveBtn.onclick = async () => {
      const file = root.querySelector('#receiptFile')?.files?.[0];
      if (!file) return toast('Pick a file.', 'error');

      try {
        const updated = await DataLayer.uploadReceipt(file, bookingId);

        try {
          if (state.user?.email) {
            await DataLayer.sendEmailAutomation({
              to: state.user.email,
              template: 'receipt-submitted',
              data: {
                ref: updated.ref,
                courtName: updated.courts?.name,
                bookingDate: updated.booking_date,
                startTime: updated.start_time,
                durationHours: updated.duration_hours,
                amount: updated.amount,
                paymentMethod: updated.payment_method,
                transactionRef: updated.transaction_ref
              }
            });
          }
        } catch (_) {}

        toast('Receipt uploaded.', 'success');
        close();
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function openInvoicePrint(b) {
  const w = window.open('', '_blank');
  if (!w || !b) return;

  w.document.write(`
    <!doctype html>
    <html>
      <head>
        <title>${esc(b.invoice_no || b.ref)}</title>
        <style>
          body{font-family:Arial;padding:32px}
          h1{margin:0 0 8px}
          .muted{color:#64748b}
          table{width:100%;border-collapse:collapse;margin-top:24px}
          td,th{border:1px solid #ddd;padding:10px}
        </style>
      </head>
      <body>
        <h1>TTAM Invoice</h1>
        <div class="muted">${esc(b.invoice_no || 'Pending')}</div>
        <table>
          <tr><th>Booking Ref</th><td>${esc(b.ref)}</td></tr>
          <tr><th>Court</th><td>${esc(b.courts?.name || '')}</td></tr>
          <tr><th>Date</th><td>${fmtDate(b.booking_date)}</td></tr>
          <tr><th>Time</th><td>${fmtTime(b.start_time)} · ${b.duration_hours}h</td></tr>
          <tr><th>Total</th><td>${fmtMoney(b.amount)}</td></tr>
          <tr><th>Payment Status</th><td>${esc(b.payment_status)}</td></tr>
        </table>
        <script>window.onload=function(){window.print()}<\/script>
      </body>
    </html>`);
  w.document.close();
}

function renderNotificationsShell() {
  return `${renderTopbar('Notifications', 'Signals from the system.')}<div id="notificationsArea"><div class="card"><div class="empty">Loading…</div></div></div>`;
}

async function hydrateNotifications() {
  const items = await DataLayer.listNotifications();

  setHtml('notificationsArea', `
    <div class="card">
      ${items.length ? items.map(n => `
        <div class="notice ${n.kind === 'warning' ? 'warn' : n.kind}" style="opacity:${n.read_at ? 0.6 : 1};cursor:pointer;" data-notif="${n.id}">
          <div style="font-weight:700;">${esc(n.title)}</div>
          <div>${esc(n.message)}</div>
          <div class="muted" style="font-size:11px;margin-top:4px;">${fmtDate(n.created_at)}${n.read_at ? ' · read' : ''}</div>
        </div>`).join('') : `<div class="empty">No notifications.</div>`}
    </div>`);

  document.querySelectorAll('[data-notif]').forEach(el => {
    el.onclick = async () => {
      try {
        await DataLayer.markNotificationRead(el.dataset.notif);
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function renderAssociation() {
  const contact = state.association.contact || {};
  const committee = state.association.committee || [];
  const byCat = c => (state.association.tournaments || []).filter(t => t.category === c);

  return `
    ${renderTopbar('Association', 'Public TTAM content managed from Association CMS.')}
    <div class="card">
      <h3>Get in touch</h3>
      <div class="grid cols-3" style="margin-top:12px;">
        <div><div class="muted" style="font-size:11px;">Address</div><div style="font-weight:600;">${esc(contact.address || '—')}</div></div>
        <div><div class="muted" style="font-size:11px;">Email</div><div style="font-weight:600;"><a href="mailto:${esc(contact.email || '')}">${esc(contact.email || '—')}</a></div></div>
        <div><div class="muted" style="font-size:11px;">Phone</div><div style="font-weight:600;">${esc(contact.phone || '—')}</div></div>
      </div>
    </div>
    <div class="card">
      <h3>Executive Committee</h3>
      <div class="grid cols-3" style="margin-top:12px;">
        ${committee.map(m => `
          <div class="card" style="margin:0;">
            <h3>${esc(m.name)}</h3>
            <div class="muted">${esc(m.role_title)}</div>
            <div style="margin-top:8px;"><a href="mailto:${esc(m.email || '')}">${esc(m.email || '')}</a></div>
            <div>${esc(m.phone || '')}</div>
          </div>`).join('')}
      </div>
    </div>
    <div class="grid cols-2">
      <div class="card"><h3>Upcoming tournaments</h3><div class="stack" style="margin-top:10px;">${byCat('upcoming').map(t => `<div><div style="font-weight:700;">${esc(t.title)}</div><div class="muted">${esc(t.meta || '')}</div></div>`).join('')}</div></div>
      <div class="card"><h3>Recent tournaments</h3><div class="stack" style="margin-top:10px;">${byCat('held').map(t => `<div><div style="font-weight:700;">${esc(t.title)}</div><div class="muted">${esc(t.meta || '')}</div></div>`).join('')}</div></div>
    </div>
    <div class="card"><h3>Winners & achievements</h3><div class="grid cols-2" style="margin-top:12px;">${byCat('winner').map(t => `<div class="card" style="margin:0;"><div class="muted" style="text-transform:uppercase;font-size:11px;">🏆 Achievement</div><h3>${esc(t.title)}</h3><div class="muted">${esc(t.meta || '')}</div></div>`).join('')}</div></div>
  `;
}

function renderContact() {
  const contact = state.association.contact || {};

  return `
    ${renderTopbar('Contact us', 'Messages are stored in Supabase and visible to admins.')}
    <div class="grid cols-2">
      <form class="card" id="contactForm">
        <h3>Send a message</h3>
        <div class="field"><label>Name</label><input class="input" id="contactName" required value="${esc(state.user?.full_name || '')}"></div>
        <div class="field"><label>Email</label><input class="input" id="contactEmail" type="email" required value="${esc(state.user?.email || '')}"></div>
        <div class="field"><label>Subject</label><input class="input" id="contactSubject"></div>
        <div class="field"><label>Message</label><textarea class="textarea" id="contactMessage" required></textarea></div>
        <button class="btn btn-primary" type="submit">Send message</button>
      </form>
      <div class="card">
        <h3>Contact details</h3>
        <div class="stack" style="margin-top:12px;">
          <div><div class="muted" style="font-size:11px;">Address</div><div style="font-weight:600;">${esc(contact.address || '—')}</div></div>
          <div><div class="muted" style="font-size:11px;">Email</div><div style="font-weight:600;"><a href="mailto:${esc(contact.email || '')}">${esc(contact.email || '—')}</a></div></div>
          <div><div class="muted" style="font-size:11px;">Phone</div><div style="font-weight:600;">${esc(contact.phone || '—')}</div></div>
          <div class="notice info"><strong>Bank transfers:</strong> ${esc(contact.bank_name || '—')} · <strong>${esc(contact.bank_account || '—')}</strong></div>
        </div>
      </div>
    </div>`;
}

function bindContact() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.onsubmit = async (e) => {
    e.preventDefault();
    try {
      await DataLayer.createContactMessage({
        name: document.getElementById('contactName').value.trim(),
        email: document.getElementById('contactEmail').value.trim(),
        subject: document.getElementById('contactSubject').value.trim(),
        message: document.getElementById('contactMessage').value.trim()
      });
      toast('Message sent.', 'success');
      form.reset();
    } catch (err) {
      toast(err.message, 'error');
    }
  };
}

function renderAdminBookingsShell() {
  return `${renderTopbar('All bookings', 'Approve or reject booking requests.')}<div id="adminBookingsArea"><div class="card"><div class="empty">Loading…</div></div></div>`;
}

async function hydrateAdminBookings() {
  const rows = await DataLayer.listAllBookings();

  setHtml('adminBookingsArea', `
    <div class="card">
      <div class="table-wrap">
        <table class="tt">
          <thead>
            <tr><th>Ref</th><th>Member</th><th>Court</th><th>Date</th><th>Status</th><th>Payment</th><th>Receipt</th><th>Actions</th></tr>
          </thead>
          <tbody>
            ${rows.map(b => `
              <tr>
                <td>${esc(b.ref)}</td>
                <td>${esc(b.profiles?.full_name || b.contact_name || '')}<div class="muted" style="font-size:10px;">${esc(b.profiles?.email || '')}</div></td>
                <td>${esc(b.courts?.name || '')}</td>
                <td>${fmtDate(b.booking_date)}<div class="muted" style="font-size:10px;">${fmtTime(b.start_time)} · ${b.duration_hours}h</div></td>
                <td><span class="${statusClass('status', b.status)}">${esc(b.status)}</span></td>
                <td><span class="${statusClass('pay', b.payment_status)}">${esc(b.payment_status)}</span></td>
                <td>${b.booking_receipts?.public_url ? `<a href="${esc(b.booking_receipts.public_url)}" target="_blank">Open</a>` : '<span class="muted">—</span>'}</td>
                <td>
                  <div class="row" style="gap:5px;">
                    ${b.status === 'Pending' ? `<button class="btn btn-sm btn-success" data-approve="${b.id}">Approve</button><button class="btn btn-sm btn-danger" data-reject="${b.id}">Reject</button>` : ''}
                  </div>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`);

  document.querySelectorAll('[data-approve]').forEach(btn => {
    btn.onclick = () => openApprovalModal(btn.dataset.approve, 'approve');
  });

  document.querySelectorAll('[data-reject]').forEach(btn => {
    btn.onclick = () => openApprovalModal(btn.dataset.reject, 'reject');
  });
}

function renderAdminPaymentsShell() {
  return `${renderTopbar('Payments', 'A tighter view of receipts and payment status.')}<div id="adminPaymentsArea"><div class="card"><div class="empty">Loading…</div></div></div>`;
}

async function hydrateAdminPayments() {
  const rows = (await DataLayer.listAllBookings()).filter(b =>
    ['Pending', 'Pending Verification', 'Paid', 'Rejected'].includes(b.payment_status)
  );

  setHtml('adminPaymentsArea', `
    <div class="card">
      <div class="table-wrap">
        <table class="tt">
          <thead>
            <tr>
              <th>Ref</th>
              <th>Member</th>
              <th>Amount</th>
              <th>Method</th>
              <th>Status</th>
              <th>Receipt</th>
              <th>Invoice</th>
            </tr>
          </thead>
          <tbody>
            ${rows.map(b => `
              <tr>
                <td>${esc(b.ref)}</td>
                <td>${esc(b.profiles?.full_name || b.contact_name || '')}</td>
                <td>${fmtMoney(b.amount)}</td>
                <td>${esc(b.payment_method || '')}</td>
                <td><span class="${statusClass('pay', b.payment_status)}">${esc(b.payment_status)}</span></td>
                <td>${b.booking_receipts?.public_url ? `<a href="${esc(b.booking_receipts.public_url)}" target="_blank">View file</a>` : '—'}</td>
                <td>${b.invoice_no ? `<button class="btn btn-sm btn-primary" data-print-invoice="${b.id}">Invoice</button>` : '—'}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`);

  document.querySelectorAll('[data-print-invoice]').forEach(btn => {
    btn.onclick = () => openInvoicePrint(rows.find(r => r.id === btn.dataset.printInvoice));
  });
}

function renderAdminTablesShell() {
  return `${renderTopbar('Courts', 'Manage playable tables, rates, and opening hours.')}<div id="adminTablesArea"><div class="card"><div class="empty">Loading…</div></div></div>`;
}

async function hydrateAdminTables() {
  const rows = await DataLayer.listCourts();

  setHtml('adminTablesArea', `
    <div class="card">
      <div class="row spread" style="margin-bottom:10px;">
        <h3>Courts</h3>
        <button class="btn btn-primary btn-sm" id="addCourtBtn">Add court</button>
      </div>
      <div class="table-wrap">
        <table class="tt">
          <thead>
            <tr>
              <th>Name</th>
              <th>Surface</th>
              <th>Rate</th>
              <th>Open</th>
              <th>Close</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            ${rows.map(c => `
              <tr>
                <td>${esc(c.name)}</td>
                <td>${esc(c.surface || '')}</td>
                <td>${fmtMoney(c.rate)}</td>
                <td>${esc(fmtTime(c.open_time) || '—')}</td>
                <td>${esc(fmtTime(c.close_time) || '—')}</td>
                <td><span class="${statusClass('status', c.status)}">${esc(c.status)}</span></td>
                <td>
                  <div class="row" style="gap:5px;">
                    <button class="btn btn-sm" data-edit-court="${c.id}">Edit</button>
                    <button class="btn btn-sm btn-danger" data-del-court="${c.id}">Delete</button>
                  </div>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`);

  const addCourtBtn = document.getElementById('addCourtBtn');
  if (addCourtBtn) addCourtBtn.onclick = () => openCourtModal();

  document.querySelectorAll('[data-edit-court]').forEach(btn => {
    btn.onclick = () => openCourtModal(rows.find(r => r.id === btn.dataset.editCourt));
  });

  document.querySelectorAll('[data-del-court]').forEach(btn => {
    btn.onclick = async () => {
      if (!confirm('Delete this court?')) return;
      try {
        await DataLayer.deleteCourt(btn.dataset.delCourt);
        toast('Court deleted.', 'success');
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function openCourtModal(court = {}) {
  openModal(court.id ? 'Edit court' : 'Add court', `
    <div class="stack">
      <div class="field">
        <label>Name</label>
        <input class="input" id="courtName" value="${esc(court.name || '')}">
      </div>

      <div class="field">
        <label>Surface</label>
        <input class="input" id="courtSurface" value="${esc(court.surface || '')}">
      </div>

      <div class="field">
        <label>Rate</label>
        <input class="input" type="number" id="courtRate" value="${esc(court.rate || 0)}">
      </div>

      <div class="grid cols-2">
        <div class="field">
          <label>Open time</label>
          <input class="input" type="time" id="courtOpenTime" value="${esc(fmtTime(court.open_time) || '08:00')}">
        </div>

        <div class="field">
          <label>Close time</label>
          <input class="input" type="time" id="courtCloseTime" value="${esc(fmtTime(court.close_time) || '22:00')}">
        </div>
      </div>

      <div class="field">
        <label>Status</label>
        <select class="select" id="courtStatus">
          ${['Active', 'Maintenance', 'Blocked'].map(s => `<option ${court.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </div>

      <button class="btn btn-primary" id="saveCourtBtn">Save</button>
    </div>`, (root, close) => {
    const saveBtn = root.querySelector('#saveCourtBtn');
    if (!saveBtn) return;

    saveBtn.onclick = async () => {
      try {
        const openTime = root.querySelector('#courtOpenTime').value;
        const closeTime = root.querySelector('#courtCloseTime').value;

        if (!openTime || !closeTime) {
          return toast('Please set both opening and closing times.', 'error');
        }

        if (openTime >= closeTime) {
          return toast('Closing time must be later than opening time.', 'error');
        }

        await DataLayer.saveCourt({
          id: court.id,
          name: root.querySelector('#courtName').value.trim(),
          surface: root.querySelector('#courtSurface').value.trim(),
          rate: root.querySelector('#courtRate').value,
          open_time: openTime,
          close_time: closeTime,
          status: root.querySelector('#courtStatus').value
        });

        toast('Court saved.', 'success');
        close();
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function renderAdminMembersShell() {
  return `${renderTopbar('Members', 'Promote admins or suspend access.')}<div id="adminMembersArea"><div class="card"><div class="empty">Loading…</div></div></div>`;
}

async function hydrateAdminMembers() {
  const rows = await DataLayer.listProfiles();

  setHtml('adminMembersArea', `
    <div class="card">
      <div class="table-wrap">
        <table class="tt">
          <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${rows.map(p => `
              <tr>
                <td>${esc(p.full_name)}</td>
                <td>${esc(p.email || '')}</td>
                <td>${esc(p.phone || '')}</td>
                <td><span class="${statusClass('role', p.role)}">${esc(p.role)}</span></td>
                <td><span class="${statusClass('status', p.status)}">${esc(p.status)}</span></td>
                <td>
                  <div class="row" style="gap:5px;">
                    <button class="btn btn-sm" data-toggle-role="${p.id}" data-current-role="${p.role}">${p.role === 'admin' ? 'Make member' : 'Make admin'}</button>
                    <button class="btn btn-sm btn-danger" data-toggle-status="${p.id}" data-current-status="${p.status}">${p.status === 'Active' ? 'Suspend' : 'Activate'}</button>
                  </div>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`);

  document.querySelectorAll('[data-toggle-role]').forEach(btn => {
    btn.onclick = async () => {
      try {
        await DataLayer.updateProfile(btn.dataset.toggleRole, {
          role: btn.dataset.currentRole === 'admin' ? 'member' : 'admin'
        });
        toast('Role updated.', 'success');
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });

  document.querySelectorAll('[data-toggle-status]').forEach(btn => {
    btn.onclick = async () => {
      try {
        await DataLayer.updateProfile(btn.dataset.toggleStatus, {
          status: btn.dataset.currentStatus === 'Active' ? 'Suspended' : 'Active'
        });
        toast('Status updated.', 'success');
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function renderAdminMessagesShell() {
  return `${renderTopbar('Messages', 'Public contact form submissions.')}<div id="adminMessagesArea"><div class="card"><div class="empty">Loading…</div></div></div>`;
}

async function hydrateAdminMessages() {
  const rows = await DataLayer.listMessages();

  setHtml('adminMessagesArea', `
    <div class="card">
      <div class="table-wrap">
        <table class="tt">
          <thead><tr><th>Name</th><th>Email</th><th>Subject</th><th>Message</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${rows.map(m => `
              <tr>
                <td>${esc(m.name)}</td>
                <td>${esc(m.email)}</td>
                <td>${esc(m.subject || '')}</td>
                <td>${esc(m.message)}</td>
                <td><span class="${statusClass('status', m.status)}">${esc(m.status)}</span></td>
                <td>${m.status === 'open' ? `<button class="btn btn-sm btn-success" data-close-msg="${m.id}">Close</button>` : '—'}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`);

  document.querySelectorAll('[data-close-msg]').forEach(btn => {
    btn.onclick = async () => {
      try {
        await DataLayer.closeMessage(btn.dataset.closeMsg);
        toast('Message closed.', 'success');
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function renderAdminAssociation() {
  const c = state.association.contact || {};
  const committee = state.association.committee || [];
  const tournaments = state.association.tournaments || [];

  return `
    ${renderTopbar('Association CMS', 'Update all public association sections from one place.')}
    <div class="card">
      <div class="row spread" style="margin-bottom:12px;"><div><h3>Contact details</h3><div class="card-sub">Shown on Association and Contact pages.</div></div><button class="btn btn-primary btn-sm" id="saveContactBtn">Save</button></div>
      <div class="grid cols-2">
        <div class="field"><label>Address</label><input class="input" id="acAddress" value="${esc(c.address || '')}"></div>
        <div class="field"><label>Email</label><input class="input" id="acEmail" value="${esc(c.email || '')}"></div>
        <div class="field"><label>Phone</label><input class="input" id="acPhone" value="${esc(c.phone || '')}"></div>
        <div class="field"><label>Bank Name</label><input class="input" id="acBankName" value="${esc(c.bank_name || '')}"></div>
      </div>
      <div class="field"><label>Bank Account</label><input class="input" id="acBankAccount" value="${esc(c.bank_account || '')}"></div>
    </div>
    <div class="card">
      <div class="row spread" style="margin-bottom:10px;"><h3>Executive Committee</h3><button class="btn btn-primary btn-sm" id="addCommitteeBtn">Add member</button></div>
      <div class="table-wrap">
        <table class="tt">
          <thead><tr><th>Name</th><th>Role</th><th>Email</th><th>Phone</th><th>Sort</th><th>Actions</th></tr></thead>
          <tbody>${committee.map(m => `<tr><td>${esc(m.name)}</td><td>${esc(m.role_title)}</td><td>${esc(m.email || '')}</td><td>${esc(m.phone || '')}</td><td>${m.sort_order}</td><td><div class="row" style="gap:5px;"><button class="btn btn-sm" data-edit-committee="${m.id}">Edit</button><button class="btn btn-sm btn-danger" data-del-committee="${m.id}">Delete</button></div></td></tr>`).join('')}</tbody>
        </table>
      </div>
    </div>
    <div class="card">
      <div class="row spread" style="margin-bottom:10px;"><h3>Tournaments & winners</h3><button class="btn btn-primary btn-sm" id="addTournamentBtn">Add item</button></div>
      <div class="table-wrap">
        <table class="tt">
          <thead><tr><th>Title</th><th>Category</th><th>Meta</th><th>Sort</th><th>Actions</th></tr></thead>
          <tbody>${tournaments.map(t => `<tr><td>${esc(t.title)}</td><td>${esc(t.category)}</td><td>${esc(t.meta || '')}</td><td>${t.sort_order}</td><td><div class="row" style="gap:5px;"><button class="btn btn-sm" data-edit-tournament="${t.id}">Edit</button><button class="btn btn-sm btn-danger" data-del-tournament="${t.id}">Delete</button></div></td></tr>`).join('')}</tbody>
        </table>
      </div>
    </div>
  `;
}

function bindAdminAssociation() {
  const saveContactBtn = document.getElementById('saveContactBtn');
  if (saveContactBtn) {
    saveContactBtn.onclick = async () => {
      try {
        await DataLayer.updateContactSettings({
          address: document.getElementById('acAddress').value.trim(),
          email: document.getElementById('acEmail').value.trim(),
          phone: document.getElementById('acPhone').value.trim(),
          bank_name: document.getElementById('acBankName').value.trim(),
          bank_account: document.getElementById('acBankAccount').value.trim(),
          updated_by: state.user.id
        });
        await loadAssociation();
        toast('Contact section updated.', 'success');
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  }

  const addCommitteeBtn = document.getElementById('addCommitteeBtn');
  if (addCommitteeBtn) addCommitteeBtn.onclick = () => openCommitteeModal();

  const addTournamentBtn = document.getElementById('addTournamentBtn');
  if (addTournamentBtn) addTournamentBtn.onclick = () => openTournamentModal();

  document.querySelectorAll('[data-edit-committee]').forEach(btn => {
    btn.onclick = () => openCommitteeModal(state.association.committee.find(x => x.id === btn.dataset.editCommittee));
  });

  document.querySelectorAll('[data-del-committee]').forEach(btn => {
    btn.onclick = async () => {
      if (!confirm('Delete this member?')) return;
      try {
        await DataLayer.deleteExecutiveCommittee(btn.dataset.delCommittee);
        await loadAssociation();
        toast('Member removed.', 'success');
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });

  document.querySelectorAll('[data-edit-tournament]').forEach(btn => {
    btn.onclick = () => openTournamentModal(state.association.tournaments.find(x => x.id === btn.dataset.editTournament));
  });

  document.querySelectorAll('[data-del-tournament]').forEach(btn => {
    btn.onclick = async () => {
      if (!confirm('Delete this item?')) return;
      try {
        await DataLayer.deleteTournament(btn.dataset.delTournament);
        await loadAssociation();
        toast('Item removed.', 'success');
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function openCommitteeModal(item = {}) {
  openModal(item.id ? 'Edit committee member' : 'Add committee member', `
    <div class="stack">
      <div class="field"><label>Name</label><input class="input" id="cmName" value="${esc(item.name || '')}"></div>
      <div class="field"><label>Role title</label><input class="input" id="cmRole" value="${esc(item.role_title || '')}"></div>
      <div class="field"><label>Email</label><input class="input" id="cmEmail" value="${esc(item.email || '')}"></div>
      <div class="field"><label>Phone</label><input class="input" id="cmPhone" value="${esc(item.phone || '')}"></div>
      <div class="field"><label>Sort order</label><input class="input" type="number" id="cmSort" value="${esc(item.sort_order || 1)}"></div>
      <button class="btn btn-primary" id="saveCmBtn">Save</button>
    </div>`, (root, close) => {
    const saveBtn = root.querySelector('#saveCmBtn');
    if (!saveBtn) return;

    saveBtn.onclick = async () => {
      try {
        await DataLayer.saveExecutiveCommittee({
          id: item.id,
          name: root.querySelector('#cmName').value.trim(),
          role_title: root.querySelector('#cmRole').value.trim(),
          email: root.querySelector('#cmEmail').value.trim(),
          phone: root.querySelector('#cmPhone').value.trim(),
          sort_order: root.querySelector('#cmSort').value
        });
        await loadAssociation();
        toast('Committee updated.', 'success');
        close();
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function openTournamentModal(item = {}) {
  openModal(item.id ? 'Edit item' : 'Add item', `
    <div class="stack">
      <div class="field"><label>Title</label><input class="input" id="tmTitle" value="${esc(item.title || '')}"></div>
      <div class="field"><label>Category</label><select class="select" id="tmCategory">${['upcoming', 'held', 'winner'].map(c => `<option value="${c}" ${item.category === c ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
      <div class="field"><label>Meta</label><input class="input" id="tmMeta" value="${esc(item.meta || '')}"></div>
      <div class="field"><label>Sort order</label><input class="input" type="number" id="tmSort" value="${esc(item.sort_order || 1)}"></div>
      <button class="btn btn-primary" id="saveTmBtn">Save</button>
    </div>`, (root, close) => {
    const saveBtn = root.querySelector('#saveTmBtn');
    if (!saveBtn) return;

    saveBtn.onclick = async () => {
      try {
        await DataLayer.saveTournament({
          id: item.id,
          title: root.querySelector('#tmTitle').value.trim(),
          category: root.querySelector('#tmCategory').value,
          meta: root.querySelector('#tmMeta').value.trim(),
          sort_order: root.querySelector('#tmSort').value
        });
        await loadAssociation();
        toast('Tournament section updated.', 'success');
        close();
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function openApprovalModal(bookingId, mode) {
  openModal(mode === 'approve' ? 'Approve booking' : 'Reject booking', `
    <div class="stack">
      <div class="field"><label>Comments</label><textarea class="textarea" id="approvalComments" placeholder="Optional note"></textarea></div>
      <button class="btn ${mode === 'approve' ? 'btn-success' : 'btn-danger'}" id="approvalSubmit">${mode === 'approve' ? 'Approve & mark paid' : 'Reject booking'}</button>
    </div>`, (root, close) => {
    const submitBtn = root.querySelector('#approvalSubmit');
    if (!submitBtn) return;

    submitBtn.onclick = async () => {
      try {
        const comments = root.querySelector('#approvalComments').value.trim();
        const booking = mode === 'approve'
          ? await DataLayer.adminApproveBooking(bookingId, comments)
          : await DataLayer.adminRejectBooking(bookingId, comments);

        if (booking?.profiles?.email) {
          try {
            await DataLayer.sendEmailAutomation({
              to: booking.profiles.email,
              template: mode === 'approve' ? 'booking-approved' : 'booking-rejected',
              data: {
                ref: booking.ref,
                courtName: booking.courts?.name,
                bookingDate: booking.booking_date,
                startTime: booking.start_time,
                durationHours: booking.duration_hours,
                amount: booking.amount,
                paymentMethod: booking.payment_method,
                invoiceNo: booking.invoice_no,
                comments
              }
            });
          } catch (_) {}
        }

        toast(`Booking ${mode}d.`, 'success');
        close();
        renderPageAsync();
      } catch (err) {
        toast(err.message, 'error');
      }
    };
  });
}

function openModal(title, html, onReady) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.innerHTML = `
    <div class="modal">
      <div class="modal-head">
        <h3>${esc(title)}</h3>
        <button class="btn btn-sm" data-close>Close</button>
      </div>
      <div class="modal-body">${html}</div>
    </div>`;

  document.body.appendChild(backdrop);

  const close = () => backdrop.remove();

  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) close();
  });

  const closeBtn = backdrop.querySelector('[data-close]');
  if (closeBtn) closeBtn.onclick = close;

  if (onReady) onReady(backdrop, close);
}

window.addEventListener('load', boot);