window.DataLayer = {
  // =========================
  // AUTH
  // =========================
  async getSession() {
    const { data, error } = await window.sb.auth.getSession();
    if (error) throw error;
    return data.session;
  },

  async getCurrentUserProfile() {
    const { data: authData, error: authError } = await window.sb.auth.getUser();
    if (authError) throw authError;
    if (!authData.user) return null;

    const { data, error } = await window.sb
      .from('profiles')
      .select('*')
      .eq('id', authData.user.id)
      .single();

    if (error) throw error;

    return {
      ...data,
      email: authData.user.email || data.email || ''
    };
  },

  async signIn(email, password) {
    const { data, error } = await window.sb.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  },

  async signUp({ email, password, full_name, phone }) {
    const { data, error } = await window.sb.auth.signUp({
      email,
      password,
      options: { data: { full_name, phone } }
    });
    if (error) throw error;
    return data;
  },

  async signOut() {
    const { error } = await window.sb.auth.signOut();
    if (error) throw error;
  },

  // =========================
  // CONTACT SETTINGS
  // =========================
  async getContactSettings() {
    const { data, error } = await window.sb
      .from('contact_settings')
      .select('*')
      .limit(1)
      .single();
    if (error) throw error;
    return data;
  },

  async updateContactSettings(payload) {
    const current = await this.getContactSettings();
    const { data, error } = await window.sb
      .from('contact_settings')
      .update({
        address: payload.address ?? null,
        email: payload.email ?? null,
        phone: payload.phone ?? null,
        bank_name: payload.bank_name ?? null,
        bank_account: payload.bank_account ?? null
      })
      .eq('id', current.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // =========================
  // EXECUTIVE COMMITTEE
  // =========================
  async listExecutiveCommittee() {
    const { data, error } = await window.sb.from('exco').select('*');
    if (error) throw error;

    return (data || [])
      .map(x => ({
        ...x,
        role_title: x.role || '',
        sort_order: x.sort_order ?? x.order ?? 1
      }))
      .sort((a, b) => Number(a.sort_order || 1) - Number(b.sort_order || 1));
  },

  async saveExecutiveCommittee(member) {
    const payload = {
      name: member.name,
      role: member.role_title,
      email: member.email || null,
      phone: member.phone || null
    };

    if ('sort_order' in member) payload.sort_order = Number(member.sort_order || 1);

    let query;
    if (member.id) {
      query = window.sb.from('exco').update(payload).eq('id', member.id);
    } else {
      query = window.sb.from('exco').insert(payload);
    }

    const { data, error } = await query.select().single();
    if (error) throw error;

    return {
      ...data,
      role_title: data.role || '',
      sort_order: data.sort_order ?? data.order ?? 1
    };
  },

  async deleteExecutiveCommittee(id) {
    const { error } = await window.sb.from('exco').delete().eq('id', id);
    if (error) throw error;
  },

  // =========================
  // TOURNAMENTS
  // =========================
  async listTournaments() {
    const { data, error } = await window.sb.from('tournaments').select('*');
    if (error) throw error;

    return (data || [])
      .map(x => ({
        ...x,
        sort_order: x.sort_order ?? 1
      }))
      .sort((a, b) => {
        const cat = String(a.category).localeCompare(String(b.category));
        if (cat !== 0) return cat;
        return Number(a.sort_order || 1) - Number(b.sort_order || 1);
      });
  },

  async saveTournament(item) {
    const payload = {
      title: item.title,
      category: item.category,
      meta: item.meta || null
    };

    if ('sort_order' in item) payload.sort_order = Number(item.sort_order || 1);

    let query;
    if (item.id) {
      query = window.sb.from('tournaments').update(payload).eq('id', item.id);
    } else {
      query = window.sb.from('tournaments').insert(payload);
    }

    const { data, error } = await query.select().single();
    if (error) throw error;

    return {
      ...data,
      sort_order: data.sort_order ?? 1
    };
  },

  async deleteTournament(id) {
    const { error } = await window.sb.from('tournaments').delete().eq('id', id);
    if (error) throw error;
  },

  // =========================
  // TABLES / COURTS
  // =========================
  async listTables() {
    const { data, error } = await window.sb.from('tables').select('*').order('name');
    if (error) throw error;
    return data || [];
  },

  async listCourts() {
    return this.listTables();
  },

  async saveTable(table) {
    const payload = {
      name: table.name,
      surface: table.surface || null,
      rate: Number(table.rate || 0),
      status: table.status || 'Active',
      open_time: table.open_time || null,
      close_time: table.close_time || null
    };

    let query;
    if (table.id) {
      query = window.sb.from('tables').update(payload).eq('id', table.id);
    } else {
      query = window.sb.from('tables').insert(payload);
    }

    const { data, error } = await query.select().single();
    if (error) throw error;
    return data;
  },

  async saveCourt(court) {
    return this.saveTable(court);
  },

  async deleteTable(id) {
    const { error } = await window.sb.from('tables').delete().eq('id', id);
    if (error) throw error;
  },

  async deleteCourt(id) {
    return this.deleteTable(id);
  },

  // =========================
  // BOOKINGS
  // =========================
  _normalizeBookingRow(b) {
    const rawReceipt =
      Array.isArray(b.receipts) ? (b.receipts[0] || null) :
      Array.isArray(b.booking_receipts) ? (b.booking_receipts[0] || null) :
      b.receipts || b.booking_receipts || null;

    const receipt = rawReceipt
      ? {
          ...rawReceipt,
          public_url: rawReceipt.public_url || rawReceipt.file_url || null
        }
      : null;

    const profile =
      Array.isArray(b.profiles) ? (b.profiles[0] || null) :
      b.profiles || null;

    return {
      ...b,
      ref: b.ref || `BK-${String(b.id).slice(0, 8).toUpperCase()}`,
      court_id: b.table_id,
      courts: b.tables || b.courts || null,
      booking_receipts: receipt,
      profiles: profile
    };
  },

  async listMyBookings() {
    const profile = await this.getCurrentUserProfile();
    if (!profile) return [];

    const { data, error } = await window.sb
      .from('bookings')
      .select('*, tables(*), receipts(*)')
      .eq('user_id', profile.id)
      .order('booking_date', { ascending: false })
      .order('start_time', { ascending: false });

    if (error) throw error;
    return (data || []).map(b => this._normalizeBookingRow(b));
  },

  async listAllBookings() {
    const { data, error } = await window.sb
      .from('bookings')
      .select('*, tables(*), profiles!bookings_user_id_fkey(*), receipts(*)')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return (data || []).map(b => this._normalizeBookingRow(b));
  },

  async createBooking(input) {
    const profile = await this.getCurrentUserProfile();

    const tableId = input.table_id || input.court_id;
    if (!tableId) throw new Error('Please select a table.');

    const { data: table, error: tableError } = await window.sb
      .from('tables')
      .select('*')
      .eq('id', tableId)
      .single();

    if (tableError) throw tableError;

    const amount = Number(table.rate || 0) * Number(input.duration_hours || 1);

    const insertPayload = {
      user_id: profile.id,
      table_id: tableId,
      booking_date: input.booking_date,
      start_time: input.start_time,
      duration_hours: Number(input.duration_hours || 1),
      amount,
      payment_method: input.payment_method || 'Bank transfer',
      notes: input.notes || '',
      status: 'Pending',
      payment_status: input.payment_method === 'Member account' ? 'Paid' : 'Pending',
      contact_name: profile.full_name || null,
      contact_phone: profile.phone || null
    };

    const { data, error } = await window.sb
      .from('bookings')
      .insert(insertPayload)
      .select('*, tables(*)')
      .single();

    if (error) throw error;

    return this._normalizeBookingRow(data);
  },

  async cancelBooking(id) {
    const { data, error } = await window.sb
      .from('bookings')
      .update({ status: 'Cancelled' })
      .eq('id', id)
      .select('*, tables(*), receipts(*)')
      .single();

    if (error) throw error;
    return this._normalizeBookingRow(data);
  },

  // =========================
  // RECEIPTS
  // =========================
  async uploadReceipt(file, bookingId) {
    const safeName = `${bookingId}-${Date.now()}-${String(file.name || 'receipt').replace(/[^a-zA-Z0-9._-]/g, '_')}`;
    const path = `${bookingId}/${safeName}`;

    const upload = await window.sb.storage.from('receipts').upload(path, file, {
      cacheControl: '3600',
      upsert: true
    });
    if (upload.error) throw upload.error;

    const publicUrl = window.sb.storage.from('receipts').getPublicUrl(path).data.publicUrl;

    const { error: receiptError } = await window.sb.from('receipts').insert({
      booking_id: bookingId,
      file_url: publicUrl
    });
    if (receiptError) throw receiptError;

    const { data: booking, error: bookingError } = await window.sb
      .from('bookings')
      .update({ payment_status: 'Pending Verification' })
      .eq('id', bookingId)
      .select('*, tables(*), receipts(*)')
      .single();

    if (bookingError) throw bookingError;

    return this._normalizeBookingRow(booking);
  },

  // =========================
  // APPROVALS
  // =========================
  async adminApproveBooking(id, comments = '') {
    const profile = await this.getCurrentUserProfile();
    const invoiceNo = `INV-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;

    const { data: booking, error: updateError } = await window.sb
      .from('bookings')
      .update({
        status: 'Confirmed',
        payment_status: 'Paid',
        invoice_no: invoiceNo
      })
      .eq('id', id)
      .select('*, tables(*), profiles!bookings_user_id_fkey(*), receipts(*)')
      .single();

    if (updateError) throw updateError;

    const { error: approvalError } = await window.sb.from('approvals').insert({
      booking_id: id,
      approved_by: profile.id,
      status: 'Approved',
      comments
    });

    if (approvalError) throw approvalError;

    return this._normalizeBookingRow(booking);
  },

  async adminRejectBooking(id, comments = '') {
    const profile = await this.getCurrentUserProfile();

    const { data: booking, error: updateError } = await window.sb
      .from('bookings')
      .update({ status: 'Rejected', payment_status: 'Rejected' })
      .eq('id', id)
      .select('*, tables(*), profiles!bookings_user_id_fkey(*), receipts(*)')
      .single();

    if (updateError) throw updateError;

    const { error: approvalError } = await window.sb.from('approvals').insert({
      booking_id: id,
      approved_by: profile.id,
      status: 'Rejected',
      comments
    });

    if (approvalError) throw approvalError;

    return this._normalizeBookingRow(booking);
  },

  // =========================
  // NOTIFICATIONS
  // =========================
  async listNotifications() {
    const profile = await this.getCurrentUserProfile();
    if (!profile) return [];

    const { data, error } = await window.sb
      .from('notifications')
      .select('*')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async markNotificationRead(id) {
    const { data, error } = await window.sb
      .from('notifications')
      .update({ read_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // =========================
  // PROFILES / MEMBERS
  // =========================
  async listProfiles() {
    const { data, error } = await window.sb
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async updateProfile(profileId, patch) {
    const { data, error } = await window.sb
      .from('profiles')
      .update(patch)
      .eq('id', profileId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // =========================
  // CONTACT MESSAGES
  // =========================
  async listMessages() {
    const { data, error } = await window.sb
      .from('contact_messages')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async createContactMessage(payload) {
    const { data, error } = await window.sb
      .from('contact_messages')
      .insert({
        name: payload.name,
        email: payload.email,
        subject: payload.subject || null,
        message: payload.message,
        status: 'open'
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async closeMessage(id) {
    const profile = await this.getCurrentUserProfile();

    const { data, error } = await window.sb
      .from('contact_messages')
      .update({
        status: 'closed',
        closed_at: new Date().toISOString(),
        closed_by: profile?.id || null
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // =========================
  // EMAIL
  // =========================
  async sendEmailAutomation(payload) {
    if (!window.APP_CONFIG?.NETLIFY_FUNCTION_BASE) {
      return { ok: false, skipped: true };
    }

    const res = await fetch(`${window.APP_CONFIG.NETLIFY_FUNCTION_BASE}/send-booking-email`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(txt || 'Email function failed');
    }

    return res.json();
  },

  // =========================
  // REALTIME
  // =========================
  subscribeToBookings(onChange) {
    return window.sb
      .channel('ttam-bookings')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings' },
        onChange
      )
      .subscribe();
  }
};