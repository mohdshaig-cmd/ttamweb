// Copy js/config.example.js values here for local testing.
window.APP_CONFIG = window.APP_CONFIG || {
  SUPABASE_URL: "https://dyymnuhwtqlmvinnhrzz.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR5eW1udWh3dHFsbXZpbm5ocnp6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY1NDE4ODYsImV4cCI6MjA5MjExNzg4Nn0.Jo0icBe2h8q9jh8fVuNHjtwKWu_nE2-vRZ74c5IbYhM",
  NETLIFY_FUNCTION_BASE: "/.netlify/functions"
};
