(function () {
  if (!window.APP_CONFIG) {
    throw new Error('APP_CONFIG is missing. Copy js/config.example.js to js/config.js and fill it in.');
  }
  if (!window.supabase || !window.supabase.createClient) {
    throw new Error('Supabase browser library not loaded.');
  }
  window.sb = window.supabase.createClient(
    window.APP_CONFIG.SUPABASE_URL,
    window.APP_CONFIG.SUPABASE_ANON_KEY,
    {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
      }
    }
  );
})();
