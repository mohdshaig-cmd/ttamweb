const BRAND = {
  appName: 'TTAM CourtFlow',
  orgName: 'Table Tennis Association of Maldives',
  primary: '#0f5db8',
  primary2: '#1d7cf2',
  text: '#0f172a',
  muted: '#64748b',
  line: '#dbe4f0',
  surface: '#f8fbff',
  success: '#0f9f67',
  danger: '#dc2626',
  warning: '#d97706'
};

function esc(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function fmtDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  return new Intl.DateTimeFormat('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).format(d);
}

function fmtMoney(value) {
  const n = Number(value || 0);
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'MVR', minimumFractionDigits: 2 }).format(n);
}

function shell({ preheader = '', title, eyebrow = 'TTAM CourtFlow', intro, sections = [], ctaLabel, ctaUrl, footerNote }) {
  return `<!doctype html>
  <html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${esc(title)}</title>
  </head>
  <body style="margin:0;padding:0;background:${BRAND.surface};font-family:Inter,Segoe UI,Arial,sans-serif;color:${BRAND.text};">
    <div style="display:none;max-height:0;overflow:hidden;opacity:0;">${esc(preheader)}</div>
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:${BRAND.surface};padding:24px 12px;">
      <tr>
        <td align="center">
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:680px;background:#ffffff;border:1px solid ${BRAND.line};border-radius:24px;overflow:hidden;box-shadow:0 18px 50px rgba(15,23,42,0.08);">
            <tr>
              <td style="padding:28px 32px;background:linear-gradient(135deg, ${BRAND.primary}, ${BRAND.primary2});color:#ffffff;">
                <div style="font-size:12px;letter-spacing:0.14em;text-transform:uppercase;opacity:0.9;font-weight:700;">${esc(eyebrow)}</div>
                <div style="font-size:30px;line-height:1.15;font-weight:800;margin-top:10px;">${esc(title)}</div>
                <div style="font-size:14px;line-height:1.7;opacity:0.95;margin-top:10px;">${intro}</div>
              </td>
            </tr>
            <tr>
              <td style="padding:28px 32px;">
                ${sections.join('')}
                ${ctaLabel && ctaUrl ? `<div style="margin-top:26px;"><a href="${esc(ctaUrl)}" style="display:inline-block;background:${BRAND.primary};color:#ffffff;text-decoration:none;padding:12px 18px;border-radius:12px;font-weight:700;">${esc(ctaLabel)}</a></div>` : ''}
              </td>
            </tr>
            <tr>
              <td style="padding:20px 32px;border-top:1px solid ${BRAND.line};color:${BRAND.muted};font-size:12px;line-height:1.7;">
                <div style="font-weight:700;color:${BRAND.text};">${esc(BRAND.orgName)}</div>
                <div>${footerNote || 'This message was sent automatically by the TTAM booking platform.'}</div>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
  </html>`;
}

function statGrid(items) {
  return `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-top:4px;margin-bottom:18px;"><tr>${items.map(item => `
    <td style="padding:0 6px 12px 0;vertical-align:top;" width="${Math.floor(100 / items.length)}%">
      <div style="border:1px solid ${BRAND.line};border-radius:18px;padding:14px 16px;background:#ffffff;">
        <div style="font-size:11px;text-transform:uppercase;letter-spacing:0.08em;color:${BRAND.muted};font-weight:700;">${esc(item.label)}</div>
        <div style="font-size:16px;line-height:1.4;color:${BRAND.text};font-weight:800;margin-top:6px;">${esc(item.value)}</div>
      </div>
    </td>`).join('')}</tr></table>`;
}

function messageBox(label, value, tone = 'neutral') {
  const toneMap = {
    neutral: { bg: '#ffffff', color: BRAND.text, border: BRAND.line },
    success: { bg: '#e7f8f0', color: BRAND.success, border: '#bfe7d1' },
    danger: { bg: '#feecec', color: BRAND.danger, border: '#f5c2c2' },
    warning: { bg: '#fff4df', color: BRAND.warning, border: '#f4ddb2' }
  };
  const t = toneMap[tone] || toneMap.neutral;
  return `<div style="border:1px solid ${t.border};background:${t.bg};border-radius:18px;padding:16px 18px;margin-top:16px;">
    <div style="font-size:11px;text-transform:uppercase;letter-spacing:0.08em;color:${BRAND.muted};font-weight:700;">${esc(label)}</div>
    <div style="font-size:15px;line-height:1.7;color:${t.color};font-weight:700;margin-top:8px;">${value}</div>
  </div>`;
}

function bookingSections(data) {
  return [
    statGrid([
      { label: 'Booking Ref', value: data.ref || '—' },
      { label: 'Court', value: data.courtName || '—' },
      { label: 'Date', value: data.bookingDate ? fmtDate(data.bookingDate) : '—' }
    ]),
    statGrid([
      { label: 'Start Time', value: data.startTime || '—' },
      { label: 'Duration', value: data.durationHours ? `${data.durationHours} hour(s)` : '—' },
      { label: 'Amount', value: fmtMoney(data.amount) }
    ]),
    data.paymentMethod ? messageBox('Payment Method', esc(data.paymentMethod)) : ''
  ];
}

function renderTemplate(template, data = {}) {
  switch (template) {
    case 'booking-submitted':
      return {
        subject: data.subject || `Booking submitted · ${data.ref || 'TTAM'}`,
        html: shell({
          preheader: `Your booking ${data.ref || ''} has been submitted.`,
          title: 'Booking submitted',
          intro: `Your session has been logged in the system and is waiting for the next step. Here is the snapshot.`,
          sections: [
            ...bookingSections(data),
            messageBox('What happens next', 'If payment verification or approval is required, you will receive another email as soon as the status changes.', 'warning')
          ]
        }),
        text: `Booking submitted. Ref: ${data.ref || ''}. Court: ${data.courtName || ''}. Date: ${data.bookingDate || ''} ${data.startTime || ''}. Amount: ${fmtMoney(data.amount)}.`
      };
    case 'booking-approved':
      return {
        subject: data.subject || `Booking approved · ${data.ref || 'TTAM'}`,
        html: shell({
          preheader: `Your booking ${data.ref || ''} is approved.`,
          title: 'Booking approved',
          intro: `Green light. Your court booking is confirmed and ready to go.`,
          sections: [
            ...bookingSections(data),
            data.invoiceNo ? messageBox('Invoice Number', esc(data.invoiceNo), 'success') : '',
            data.comments ? messageBox('Admin Note', esc(data.comments), 'success') : ''
          ]
        }),
        text: `Booking approved. Ref: ${data.ref || ''}. ${data.comments || ''}`
      };
    case 'booking-rejected':
      return {
        subject: data.subject || `Booking update · ${data.ref || 'TTAM'}`,
        html: shell({
          preheader: `Your booking ${data.ref || ''} was not approved.`,
          title: 'Booking not approved',
          intro: `This booking could not be approved in its current form. The details are below.`,
          sections: [
            ...bookingSections(data),
            messageBox('Reason / Comment', esc(data.comments || 'No additional comment was provided.'), 'danger')
          ]
        }),
        text: `Booking rejected. Ref: ${data.ref || ''}. Reason: ${data.comments || 'No comment'}`
      };
    case 'receipt-submitted':
      return {
        subject: data.subject || `Receipt uploaded · ${data.ref || 'TTAM'}`,
        html: shell({
          preheader: `Receipt uploaded for booking ${data.ref || ''}.`,
          title: 'Receipt received',
          intro: `Your payment receipt has landed in the queue and is waiting for admin verification.`,
          sections: [
            ...bookingSections(data),
            data.transactionRef ? messageBox('Transaction Reference', esc(data.transactionRef), 'neutral') : '',
            messageBox('Status', 'Pending verification', 'warning')
          ]
        }),
        text: `Receipt submitted for ${data.ref || ''}. Transaction reference: ${data.transactionRef || 'N/A'}.`
      };
    case 'admin-receipt-alert':
      return {
        subject: data.subject || `Receipt waiting for verification · ${data.ref || 'TTAM'}`,
        html: shell({
          preheader: `Receipt uploaded for booking ${data.ref || ''}.`,
          title: 'Receipt waiting for review',
          intro: `${esc(data.memberName || 'A member')} uploaded a receipt. Time to peek behind the curtain and verify it.`,
          sections: [
            ...bookingSections(data),
            data.transactionRef ? messageBox('Transaction Reference', esc(data.transactionRef), 'neutral') : '',
            data.receiptUrl ? messageBox('Receipt Link', `<a href="${esc(data.receiptUrl)}" style="color:${BRAND.primary};font-weight:700;">Open uploaded receipt</a>`, 'warning') : ''
          ],
          ctaLabel: data.adminUrl ? 'Open admin panel' : undefined,
          ctaUrl: data.adminUrl
        }),
        text: `Admin alert: receipt uploaded for ${data.ref || ''} by ${data.memberName || 'member'}.`
      };
    default:
      return {
        subject: data.subject || 'TTAM notification',
        html: shell({
          preheader: data.preheader || 'TTAM notification',
          title: data.title || 'TTAM notification',
          intro: data.intro || 'A new update is available.',
          sections: [messageBox('Message', esc(data.message || 'Please review the latest update.'), 'neutral')]
        }),
        text: data.message || 'TTAM notification'
      };
  }
}

export async function handler(event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  try {
    if (!process.env.RESEND_API_KEY) {
      return { statusCode: 500, body: JSON.stringify({ ok: false, error: 'Missing RESEND_API_KEY environment variable.' }) };
    }

    const body = JSON.parse(event.body || '{}');
    const { to, subject, html, text, template, data } = body;

    if (!to) {
      return { statusCode: 400, body: 'Missing recipient.' };
    }

    let emailPayload;
    if (template) {
      emailPayload = renderTemplate(template, { ...(data || {}), subject });
    } else {
      if (!subject || (!html && !text)) {
        return { statusCode: 400, body: 'Missing subject and email content.' };
      }
      emailPayload = { subject, html, text };
    }

    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM || 'TTAM <onboarding@resend.dev>',
        to: Array.isArray(to) ? to : [to],
        subject: emailPayload.subject,
        html: emailPayload.html,
        text: emailPayload.text,
      })
    });

    const json = await response.json();
    if (!response.ok) {
      return { statusCode: response.status, body: JSON.stringify(json) };
    }

    return { statusCode: 200, body: JSON.stringify({ ok: true, provider: 'resend', result: json }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ ok: false, error: error.message }) };
  }
}
